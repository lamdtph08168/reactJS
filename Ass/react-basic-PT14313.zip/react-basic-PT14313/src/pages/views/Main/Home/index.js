import React from 'react'
import PropTypes from 'prop-types'

const Home = props => {
    return (
        <div>
            Home Page
        </div>
    )
}

Home.propTypes = {

}

export default Home
